# Screenshot / visual evidence bundle

This bundle adds a `screenshots/` directory to each lab where visual evidence is available.

- Labs 1–3: PNG page renders of the supplied requirements documents, Jira deliverables, architecture documents and diagrams. These are document-page renders, not claims of live application screenshots.
- Lab 4: frames and posters taken from the supplied before/after gameplay videos.
- Lab 5: output captured by running the supplied Python demonstration in this environment. The original before/after static-analysis reports remain in `deliverables/reports/`.
- Lab 6: the two screenshots already supplied with the source archive, copied into a consistent `screenshots/` folder. Originals remain in `deliverables/screenshots/`.
- Lab 7: first-page render of the supplied fuzz-testing report and output from running the supplied CLI with sample inputs. The existing test file uses Hypothesis; a full fuzz/property-test run has not been represented as completed here.

These are genuine renders, supplied video frames, or reproduced command outputs. They are not fabricated screenshots of Jira, a browser, or a student's desktop. Please confirm with your TA whether live application screenshots are required in addition to these artifacts.
